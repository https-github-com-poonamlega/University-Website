http_path = "/"
css_dir = "css"
sass_dir = "scss"
images_dir = "img"
javascripts_dir = "js"
output_style = :compressed
line_comments = false # by Compass.app 
output_style = :expanded # by Compass.app 